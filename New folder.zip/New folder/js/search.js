document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('search-form');
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    const categoryFilters = document.getElementById('category-filters');
    const filterButtons = categoryFilters.querySelectorAll('button');
    const homeButton = document.querySelector('nav ul li a[href="index.html"]');

    let currentResults = [];

    // Function to reset the search and filters
    function resetSearch() {
        searchInput.value = '';
        searchResults.innerHTML = '';
        categoryFilters.style.display = 'none'; // Hide categories until a search is performed
        // Ensure all category buttons are re-enabled
        filterButtons.forEach(button => {
            button.style.display = 'inline-block'; // Ensure all buttons are visible
        });
    }

    // Handle the search form submission
    searchForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent form submission
        const query = searchInput.value.toLowerCase();
        searchResults.innerHTML = ''; // Clear previous results

        // Perform the search through the policies
        currentResults = performSearch(query);
        displayResults(currentResults);

        // Show category filters if results are found
        if (currentResults.length > 0) {
            categoryFilters.style.display = 'block';
        } else {
            categoryFilters.style.display = 'none';
        }
    });

    // Filter the results by category when a category button is clicked
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const category = button.getAttribute('data-category');
            const filteredResults = currentResults.filter(policy => policy.category === category);
            displayResults(filteredResults);
        });
    });

    // Function to search through policies
    function performSearch(query) {
        const policies = getAllPolicies(); // This function should return all policies
        return policies.filter(policy => policy.title.toLowerCase().includes(query));
    }

    // Function to display search results
    function displayResults(results) {
        searchResults.innerHTML = '';
        if (results.length > 0) {
            results.forEach(policy => {
                const li = document.createElement('li');
                const link = document.createElement('a');
                link.href = policy.path;
                link.textContent = policy.title;
                li.appendChild(link);
                searchResults.appendChild(li);
            });
        } else {
            searchResults.innerHTML = '<li>No policies found.</li>';
        }
    }
  

    // Reset the search and filters when clicking on the Home button
    if (homeButton) {
        homeButton.addEventListener('click', function() {
            resetSearch();
        });
    }

    // Initial reset when the page loads
    resetSearch();
});




function getAllPolicies() { return [
    { title: 'Acupuncture', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/III-01/III-01-011.html', category: 'ancillary_services' },
    { title: 'Hypnotherapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/III-02/III-02-010.html', category: 'ancillary_services' },
    { title: 'Cognitive Rehabilitation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/III-03/III-03-007.html', category: 'ancillary_services' },
    { title: 'Chiropractic Services', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/III-04/III-04-006.html', category: 'ancillary_services' },
    { title: 'Extended Hours Skilled Nursing in the Home for Patients with Medically Complex Conditions', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/IX-01/IX-01-012.html', category: 'ancillary_services' },
    { title: 'Eyelid Thermal Pulsation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/ix-05/ix-05-001.html', category: 'ancillary_services' },
    { title: 'Virtual Reality', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/ix-06/ix-06-001.html', category: 'ancillary_services' },
    { title: 'Hippotherapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-03/VII-03-010.html', category: 'ancillary_services' },
    { title: 'Wheelchairs - Mobility Assistive Equipment', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-04/VII-04-011.html', category: 'ancillary_services' },
    { title: 'Continuous Glucose Monitoring Systems', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-05/VII-05-013.html', category: 'ancillary_services' },
    { title: 'Functional Neuromuscular Electrical Stimulation Devices in the Home Setting', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-11/VII-11-010.html', category: 'ancillary_services' },
    { title: 'Automated Point-of-Care Nerve Conduction Tests', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-12/VII-12-010.html', category: 'ancillary_services' },
    { title: 'Traction Decompression of the Spine', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-18/VII-18-010.html', category: 'ancillary_services' },
    { title: 'Electrical/Electromagnetic Stimulation for Treatment of Arthritis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-24/VII-24-010.html', category: 'ancillary_services' },
    { title: 'Oscillatory Devices for the Treatment of Cystic Fibrosis and Other Respiratory Disorders in the Home', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-35/VII-35-010.html', category: 'ancillary_services' },
    { title: 'Speech Generating Devices (SGD)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-52/VII-52-009.html', category: 'ancillary_services' },
    { title: 'Pressure-Reducing Support Surfaces', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-54/VII-54-011.html', category: 'ancillary_services' },
    { title: 'Spinal Unloading Devices: Patient-Operated', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-59/VII-59-010.html', category: 'ancillary_services' },
    { title: 'Mechanical Stretching Devices', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-62/VII-62-007.html', category: 'ancillary_services' },
    { title: 'Powered Exoskeleton', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-63/VII-63-006.html', category: 'ancillary_services' },
    { title: 'Interferential Current Stimulation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-66/VII-66-006.html', category: 'ancillary_services' },
    { title: 'Dry Needling', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Ancillary_Services/VII-67/VII-67-005.html', category: 'ancillary_services' },
    { title: 'Transcranial Magnetic Stimulation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Behavioral_Health/X-14/X-14-011.html', category: 'behavioral_health' },
    { title: 'Neurofeedback', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Behavioral_Health/X-29/X-29-011.html', category: 'behavioral_health' },
    { title: 'Cranial Electrotherapy Stimulation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Behavioral_Health/X-32/X-32-012.html', category: 'behavioral_health' },
    { title: 'Autism Spectrum Disorder: Assessment and Early Intensive Behavioral Intervention', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Behavioral_Health/X-43/X-43-011.html', category: 'behavioral_health' },
    { title: 'Psychological and Neuropsychological Testing', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Behavioral_Health/X-45/X-45-011.html', category: 'behavioral_health' },
    { title: 'Electroconvulsive Therapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Behavioral_Health/X-46/X-46-007.html', category: 'behavioral_health' },
    { title: "Genetic Testing for Familial Alzheimer's Disease", path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-04/VI-04-015.html', category: 'laboratory' },
    { title: 'Hair Analysis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-06/VI-06-010.html', category: 'laboratory' },
    { title: 'Saliva Hormone Tests', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-08/VI-08-010.html', category: 'laboratory' },
    { title: 'Gene Expression Profiling for the Management of Breast Cancer Treatment', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-10/VI-10-017.html', category: 'laboratory' },
    { title: 'Genetic Testing for Hereditary Breast and/or Ovarian Cancer', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-16/VI-16-011.html', category: 'laboratory' },
    { title: 'Testing of Circulating Tumor Cells', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-25/VI-25-015.html', category: 'laboratory' },
    { title: 'Gene Expression Profiling or Genetic Testing for Melanoma', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-26/VI-26-012.html', category: 'laboratory' },
    { title: 'In Vitro Chemoresistance and Chemosensitivity Assays', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-30/VI-30-010.html', category: 'laboratory' },
    { title: 'Single-Nucleotide Polymorphism (SNP) Breast Cancer Risk Assessment', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-32/VI-32-015.html', category: 'laboratory' },
    { title: 'Genetic Testing for Warfarin Dose', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-33/VI-33-015.html', category: 'laboratory' },
    { title: 'Multigene Expression Assays for Predicting Risk of Recurrence in Colon Cancer', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-34/VI-34-016.html', category: 'laboratory' },
    { title: 'Gene Expression Testing for Cancers of Unknown Primary', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-38/VI-38-016.html', category: 'laboratory' },
    { title: 'Laboratory and Genetic Testing for Use of 5-Fluorouracil (5-FU) in Patients with Cancer', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-41/VI-41-015.html', category: 'laboratory' },
    { title: 'Testing of Fetal Nucleic Acids in Maternal Blood for Detection of Fetal Aneuploidy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-43/VI-43-015.html', category: 'laboratory' },
    { title: 'Genetic Testing for FMR1 Mutations (Including Fragile X Syndrome)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-44/VI-44-015.html', category: 'laboratory' },
    { title: 'Proteomics-Based Testing Panels for the Evaluation of Ovarian (Adnexal) Masses', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-45/VI-45-015.html', category: 'laboratory' },
    { title: 'Molecular Marker Evaluation of Thyroid Nodules', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-50/VI-50-016.html', category: 'laboratory' },
    { title: 'Expanded Cardiovascular Risk Panels', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-51/VI-51-010.html', category: 'laboratory' },
    { title: 'Genetic Testing for Statin-Induced Myopathy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-52/VI-52-014.html', category: 'laboratory' },
    { title: 'Measurement of Serum Antibodies to Selected Biologic Agents', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-55/VI-55-011.html', category: 'laboratory' },
    { title: 'Genetic  Cancer Susceptibility Panels', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-56/VI-56-010.html', category: 'laboratory' },
    { title: 'Gene Expression Profiling and Protein Biomarkers for Prostate Cancer Management', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/VI-57/VI-57-009.html', category: 'laboratory' },
    { title: 'Expanded Gastrointestinal Biomarker Panels', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/vi-59/vi-59-004.html', category: 'laboratory' },
    { title: 'Vitamin D Screening', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/vi-60/vi-60-003.html', category: 'laboratory' },
    { title: 'Adjunctive Techniques for Screening and Surveillance of Barrett’s Esophagus and Esophageal Dysplasia', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Laboratory/vi-61/vi-61-002.html', category: 'laboratory' },
    { title: 'Prolotherapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-06/II-06-009.html', category: 'medicine' },
    { title: 'Nonpharmacologic Treatment of Rosacea', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-08/II-08-012.html', category: 'medicine' },
    { title: 'Low-Level Laser Therapy and Deep Tissue Laser Therapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-09/II-09-010.html', category: 'medicine' },
    { title: 'Pharmacologic Therapies for Hereditary Angioedema', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-102/II-102-011.html', category: 'medicine' },
    { title: 'Bone Growth Stimulators for Spinal Indications', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-104/II-104-009.html', category: 'medicine' },
    { title: 'Sleep Disorder Testing in Adults', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-106/II-106-014.html', category: 'medicine' },
    { title: 'Advanced Pharmacologic Therapies for Pulmonary Arterial Hypertension', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-107/II-107-015.html', category: 'medicine' },
    { title: 'Computerized Dynamic Posturography', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-108/II-108-010.html', category: 'medicine' },
    { title: 'Helicobacter Pylori (H. Pylori) Serology Testing', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-109/ii-109-003.html', category: 'medicine' },
    { title: 'Extracorporeal Shock Wave Treatment for Musculoskeletal Conditions and Soft Tissue Repair', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-11/II-11-010.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Acute Myeloid Leukemia', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-115/II-115-010.html', category: 'medicine' },
    { title: 'Spinal Manipulation Under Anesthesia', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-116/II-116-009.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Acute Lymphoblastic Leukemia', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-118/II-118-010.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Autoimmune Disease', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-121/II-121-009.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Chronic Lymphocytic Leukemia and Small Lymphocytic Lymphoma', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-122/II-122-011.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Miscellaneous Solid Tumors in Adults', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-123/II-123-010.html', category: 'medicine' },
    { title: 'Actigraphy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-127/II-127-012.html', category: 'medicine' },
    { title: 'Sleep Studies/Polysomnograms in Children and Adolescents', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-128/II-128-012.html', category: 'medicine' },
    { title: 'Allogeneic Hematopoietic Stem Cell Transplantation for Genetic Diseases and Acquired Anemias', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-129/II-129-010.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Central Nervous System (CNS) Embryonal Tumors and Ependymoma', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-130/II-130-011.html', category: 'medicine' },
    { title: 'Electromagnetic Navigational Bronchoscopy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-132/II-132-010.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Myelodysplastic Syndrome and Myeloproliferative Neoplasms', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-133/II-133-011.html', category: 'medicine' },
    { title: 'Wireless Gastric Motility Monitoring', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-134/II-134-010.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Hodgkin Lymphoma', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-135/II-135-011.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Chronic Myelogenous Leukemia', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-136/II-136-011.html', category: 'medicine' },
    { title: 'Hematopoietic Stem Cell Transplantation for Multiple Myeloma and POEMS Syndrome', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-138/II-138-010.html', category: 'medicine' },
    { title: 'Occipital Nerve Stimulation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-140/II-140-010.html', category: 'medicine' },
    { title: 'Stem Cell Therapy for Orthopedic Applications', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-142/II-142-011.html', category: 'medicine' },
    { title: 'Injectable Clostridial Collagenase for Fibroproliferative Disorders', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-145/II-145-006.html', category: 'medicine' },
    { title: 'Pegloticase', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-147/II-147-009.html', category: 'medicine' },
    { title: 'Bioimpedance Spectroscopy Devices for Detection and Management of Lymphedema', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-148/II-148-010.html', category: 'medicine' },
    { title: 'Belimumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-152/II-152-015.html', category: 'medicine' },
    { title: 'Diagnosis and Treatment of Chronic Cerebrospinal Venous Insufficiency (CCSVI) in Multiple Sclerosis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-155/II-155-010.html', category: 'medicine' },
    { title: 'Botulinum Toxin', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-16/II-16-019.html', category: 'medicine' },
    { title: 'Air Ambulance', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-160/II-160-010.html', category: 'medicine' },
    { title: 'Abatacept', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-161/II-161-016.html', category: 'medicine' },
    { title: 'Infusion or Injection of Vitamins and/or Minerals', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-163/II-163-010.html', category: 'medicine' },
    { title: 'Lyme Disease: Diagnostic Testing and Intravenous Antibiotic Therapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-165/II-165-010.html', category: 'medicine' },
    { title: 'Anesthesia Services for Dental Procedures', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-166/II-166-014.html', category: 'medicine' },
    { title: 'Vestibular Evoked Myogenic Potential (VEMP) Testing', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-167/II-167-010.html', category: 'medicine' },
    { title: 'Ustekinumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-168/II-168-015.html', category: 'medicine' },
    { title: 'Sublingual Immunotherapy Drops for Allergy Treatment', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-169/II-169-010.html', category: 'medicine' },
    { title: 'Eteplirsen', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-172/II-172-008.html', category: 'medicine' },
    { title: 'Evaluation Process for New FDA-Approved Medical Drugs or Medical Drug Indications', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-174/II-174-008.html', category: 'medicine' },
    { title: 'Cerliponase Alfa', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-176/II-176-008.html', category: 'medicine' },
    { title: 'Nerve Fiber Density Measurement', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-177/II-177-007.html', category: 'medicine' },
    { title: 'Edaravone', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-178/II-178-011.html', category: 'medicine' },
    { title: 'Certolizumab Pegol', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-179/II-179-013.html', category: 'medicine' },
    { title: 'Tocilizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-181/II-181-014.html', category: 'medicine' },
    { title: 'Tisagenlecleucel', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-183/II-183-010.html', category: 'medicine' },
    { title: 'Alemtuzumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-184/II-184-010.html', category: 'medicine' },
    { title: 'Ocrelizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-185/II-185-011.html', category: 'medicine' },
    { title: 'Axicabtagene Ciloleucel', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-187/II-187-009.html', category: 'medicine' },
    { title: 'Voretigene Neparvovec', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-188/II-188-006.html', category: 'medicine' },
    { title: 'Transcatheter Arterial Chemoembolization to Treat Primary or Metastatic Liver Malignancies', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-190/II-190-006.html', category: 'medicine' },
    { title: 'Confocal Laser Endomicroscopy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-191/II-191-006.html', category: 'medicine' },
    { title: 'Extracorporeal Photopheresis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-194/II-194-006.html', category: 'medicine' },
    { title: 'Sphenopalatine Ganglion Nerve Block', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-195/II-195-006.html', category: 'medicine' },
    { title: 'Eculizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-196/II-196-014.html', category: 'medicine' },
    { title: 'Bezlotoxumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-199/II-199-006.html', category: 'medicine' },
    { title: 'Mobile Cardiac Outpatient Telemetry', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-20/II-20-011.html', category: 'medicine' },
    { title: 'Sebelipase Alfa', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-200/II-200-009.html', category: 'medicine' },
    { title: 'Mepolizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-201/II-201-014.html', category: 'medicine' },
    { title: 'Reslizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-202/II-202-011.html', category: 'medicine' },
    { title: 'Benralizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-203/II-203-011.html', category: 'medicine' },
    { title: 'Emapalumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-204/II-204-008.html', category: 'medicine' },
    { title: 'Corneal Collagen Cross-Linking', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-207/II-207-006.html', category: 'medicine' },
    { title: 'Romiplostim', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-211/II-211-009.html', category: 'medicine' },
    { title: 'Burosumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-212/II-212-008.html', category: 'medicine' },
    { title: 'Intravenous Enzyme Replacement Therapy for Gaucher Disease', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-214/II-214-009.html', category: 'medicine' },
    { title: 'Idursulfase', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-215/II-215-008.html', category: 'medicine' },
    { title: 'Laronidase', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-216/II-216-008.html', category: 'medicine' },
    { title: 'Galsulfase', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-217/II-217-008.html', category: 'medicine' },
    { title: 'Patisiran', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-220/II-220-008.html', category: 'medicine' },
    { title: 'Medical Marijuana (Cannabis)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-221/II-221-006.html', category: 'medicine' },
    { title: 'Naltrexone Implants', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-223/II-223-005.html', category: 'medicine' },
    { title: 'Implantable Ambulatory Cardiac Event Monitors and Intracardiac Ischemia Monitoring Systems', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-224/II-224-005.html', category: 'medicine' },
    { title: 'Enzyme Replacement Therapy for the Treatment of Adenosine Deaminase Severe Combined Immune Deficiency (ADA-SCID)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-227/II-227-006.html', category: 'medicine' },
    { title: 'Ravulizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-229/II-229-010.html', category: 'medicine' },
    { title: 'Secretin Infusion Therapy for Autism', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-23/II-23-010.html', category: 'medicine' },
    { title: 'Onasemnogene Abeparvovec', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-230/II-230-006.html', category: 'medicine' },
    { title: 'Golodirsen', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-232/ii-232-004.html', category: 'medicine' },
    { title: 'Givosiran', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-234/ii-234-004.html', category: 'medicine' },
    { title: 'Romosozumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-236/ii-236-005.html', category: 'medicine' },
    { title: 'Luspatercept', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-237/ii-237-005.html', category: 'medicine' },
    { title: 'Afamelanotide', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-238/ii-238-004.html', category: 'medicine' },
    { title: 'Teprotumumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-239/ii-239-007.html', category: 'medicine' },
    { title: 'Intravenous Iron Replacement Therapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-243/ii-243-006.html', category: 'medicine' },
    { title: 'Inebilizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-244/ii-244-007.html', category: 'medicine' },
    { title: 'Viltolarsen', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-246/ii-246-004.html', category: 'medicine' },
    { title: 'Medicare Part B Step Therapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-247/ii-247-005.html', category: 'medicine' },
    { title: 'Lumasiran', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-248/ii-248-005.html', category: 'medicine' },
    { title: 'Evinacumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-250/ii-250-003.html', category: 'medicine' },
    { title: 'Casimersen', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-251/ii-251-003.html', category: 'medicine' },
    { title: 'Aducanumab – Commercial', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-253/ii-253-003.html', category: 'medicine' },
    { title: 'Anifrolumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-255/ii-255-003.html', category: 'medicine' },
    { title: 'Avalglucosidase Alfa', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-256/ii-256-002.html', category: 'medicine' },
    { title: 'Triamcinolone Acetonide Suprachoroidal Injection', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-257/ii-257-002.html', category: 'medicine' },
    { title: 'Inclisiran', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-258/ii-258-004.html', category: 'medicine' },
    { title: 'Tezepelumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-259/ii-259-003.html', category: 'medicine' },
    { title: 'Agalsidase Beta', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-26/II-26-009.html', category: 'medicine' },
    { title: 'Efgartigimod alfa', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-260/ii-260-004.html', category: 'medicine' },
    { title: 'Monitored Anesthesia Care with Selected Injections for Pain', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-261/ii-261-002.html', category: 'medicine' },
    { title: 'Ciltacabtagene Autoleucel', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-262/ii-262-003.html', category: 'medicine' },
    { title: 'Sutimlimab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-263/ii-263-004.html', category: 'medicine' },
    { title: 'Betibeglogene autotemcel', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-267/ii-267-003.html', category: 'medicine' },
    { title: 'Elivaldogene autotemcel', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-268/ii-268-002.html', category: 'medicine' },
    { title: 'Intravenous Anesthetics for Treatment of Chronic Pain and Psychiatric Disorders', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-271/ii-271-001.html', category: 'medicine' },
    { title: 'Ublituximab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-275/ii-275-002.html', category: 'medicine' },
    { title: 'Pegcetacoplan', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-277/ii-277-001.html', category: 'medicine' },
    { title: 'Velmanase alfa', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-278/ii-278-001.html', category: 'medicine' },
    { title: 'Tofersen', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-280/ii-280-001.html', category: 'medicine' },
    { title: 'Valoctocogene roxaparvovec', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-286/ii-286-001.html', category: 'medicine' },
    { title: 'Intra-Articular Hyaluronan Injections for Osteoarthritis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-29/II-29-015.html', category: 'medicine' },
    { title: 'Nonpharmacologic Treatment of Acne', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-33/II-33-012.html', category: 'medicine' },
    { title: 'Omalizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-34/II-34-013.html', category: 'medicine' },
    { title: 'Progesterone Therapy to Reduce Preterm Birth in High-Risk Pregnancies', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-38/II-38-011.html', category: 'medicine' },
    { title: 'Phototherapy in the Treatment of Psoriasis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-39/II-39-010.html', category: 'medicine' },
    { title: 'Selected Treatments for Tinnitus', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-42/II-42-010.html', category: 'medicine' },
    { title: 'Cardiac Hemodynamic Monitoring for the Management of Heart Failure in the Outpatient Setting', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-43/II-43-010.html', category: 'medicine' },
    { title: 'Photodynamic Therapy for Skin Conditions', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-46/II-46-011.html', category: 'medicine' },
    { title: 'Rituximab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-47/II-47-020.html', category: 'medicine' },
    { title: 'Natalizumab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-49/II-49-012.html', category: 'medicine' },
    { title: 'Quantitative Sensory Testing', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-54/II-54-010.html', category: 'medicine' },
    { title: 'Selected Treatments for Hyperhidrosis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-55/II-55-011.html', category: 'medicine' },
    { title: 'Amino Acid-Based Elemental Formulas', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-69/II-69-010.html', category: 'medicine' },
    { title: 'Biofeedback', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/ii-70/ii-70-003.html', category: 'medicine' },
    { title: 'Intravitreal Angiogenesis Inhibitors for Treatment of Retinal and Choroidal Vascular Conditions', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-71/II-71-016.html', category: 'medicine' },
    { title: 'Platelet-Rich Plasma', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-76/II-76-010.html', category: 'medicine' },
    { title: 'Optical Coherence Tomography of the Anterior Eye Segment', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-79/II-79-010.html', category: 'medicine' },
    { title: 'Percutaneous Electrical Nerve Stimulation (PENS) or Percutaneous Neuromodulation Therapy (PNT)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-81/II-81-010.html', category: 'medicine' },
    { title: 'Wound Healing:  Non-Contact Ultrasound Treatment', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-88/II-88-009.html', category: 'medicine' },
    { title: 'Wearable Cardioverter Defibrillators', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-91/II-91-007.html', category: 'medicine' },
    { title: 'Infliximab', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-97/II-97-020.html', category: 'medicine' },
    { title: 'Uterine Fibroid Ablation: Laparoscopic, Percutaneous or Transcervical Techniques', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Medicine/II-98/II-98-010.html', category: 'medicine' },
    { title: 'Medical Necessity Criteria for Medical Technologies Which Are Not Addressed by a Specific Medical Policy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Miscellaneous/XI-02/XI-02-006.html', category: 'miscellaneous' },
    { title: 'Site of Service for Selected Outpatient Procedures: Outpatient Hospital and Ambulatory Surgery Center', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Miscellaneous/XI-03/XI-03-008.html', category: 'miscellaneous' },
    { title: 'Cosmetic Criteria for Services Which Are Not Addressed by a Specific Medical Policy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Miscellaneous/XI-04/XI-04-005.html', category: 'miscellaneous' },
    { title: 'Site of Service for Selected Specialty Medical Drugs', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Miscellaneous/xi-06/xi-06-014.html', category: 'miscellaneous' },
    { title: 'Percutaneous Vertebroplasty, Kyphoplasty, and Sacroplasty', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-05/V-05-010.html', category: 'radiology' },
    { title: 'Scintimammography/Breast-Specific Gamma Imaging/Molecular Breast Imaging', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-06/V-06-015.html', category: 'radiology' },
    { title: 'Computed Tomography (CT) to Detect Coronary Artery Calcification', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-09/V-09-015.html', category: 'radiology' },
    { title: 'Transcatheter Uterine Artery Embolization', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-10/V-10-010.html', category: 'radiology' },
    { title: 'Wireless Capsule Endoscopy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-12/V-12-010.html', category: 'radiology' },
    { title: 'Computed Tomography Angiography (CTA) for Evaluation of Coronary Arteries', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-14/V-14-014.html', category: 'radiology' },
    { title: 'Dynamic Spinal Visualization and Vertebral Motion Analysis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-17/V-17-005.html', category: 'radiology' },
    { title: 'Proton Beam Radiation Therapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-20/V-20-014.html', category: 'radiology' },
    { title: 'Positron Emission Mammography', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-24/V-24-015.html', category: 'radiology' },
    { title: 'Whole Body Dual X-Ray Absorptiometry (DXA) to Determine Body Composition', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Radiology/V-28/V-28-010.html', category: 'radiology' },
    { title: 'Balloon Ostial Dilation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-01/IV-01-008.html', category: 'surgery' },
    { title: 'Microwave Ablation of Solid Tumors', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-04/IV-04-010.html', category: 'surgery' },
    { title: 'Treatment of Obstructive Sleep Apnea and Snoring in Adults', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-07/IV-07-013.html', category: 'surgery' },
    { title: 'Islet Cell Transplantation and Cellular Therapy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-09/IV-09-011.html', category: 'surgery' },
    { title: 'Hip Arthroplasty (Hip Replacement) and Hip Resurfacing', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-107/IV-107-010.html', category: 'surgery' },
    { title: 'Humanitarian Use Devices', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-11/iv-11-005.html', category: 'surgery' },
    { title: 'Facet Arthroplasty', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-110/IV-110-010.html', category: 'surgery' },
    { title: 'Intraosseous Nerve Ablation for Chronic Low Back Pain', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-111/IV-111-003.html', category: 'surgery' },
    { title: 'Surgical Treatment of Femoroacetabular Impingement', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-112/IV-112-011.html', category: 'surgery' },
    { title: 'Osteochondral Allografts and Autografts in the Treatment of Focal Articular Cartilage Lesions', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-115/IV-115-012.html', category: 'surgery' },
    { title: 'Bronchial Thermoplasty', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-117/IV-117-011.html', category: 'surgery' },
    { title: 'Ultrasound-Guided High-Intensity Focused Ultrasound Ablation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-118/IV-118-010.html', category: 'surgery' },
    { title: 'MRI-Guided High-Intensity Focused Ultrasound Ablation and MRI-Guided High-Intensity Directional Ultrasound Ablation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-119/IV-119-010.html', category: 'surgery' },
    { title: 'Image-Guided Minimally Invasive Decompression for Spinal Stenosis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-120/IV-120-009.html', category: 'surgery' },
    { title: 'Magnetic Esophageal Ring for Treatment of Gastroesophageal Reflux Disease (GERD)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-124/IV-124-009.html', category: 'surgery' },
    { title: 'Sacroiliac Joint Fusion', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-126/IV-126-011.html', category: 'surgery' },
    { title: 'Organ Transplantation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-128/IV-128-011.html', category: 'surgery' },
    { title: 'Selected Treatments for Varicose Veins of the Lower Extremities', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-129/IV-129-012.html', category: 'surgery' },
    { title: 'Ablation of Peripheral Nerves to Treat Pain', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-130/IV-130-008.html', category: 'surgery' },
    { title: 'Vagus Nerve Stimulation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-131/IV-131-007.html', category: 'surgery' },
    { title: 'Injectable Bulking Agents for the Treatment of Urinary and Fecal Incontinence', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-133/IV-133-007.html', category: 'surgery' },
    { title: 'Pelvic Floor Stimulation as a Treatment of Urinary Incontinence', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-134/IV-134-007.html', category: 'surgery' },
    { title: 'Percutaneous Tibial Nerve Stimulation (PTNS)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-135/IV-135-006.html', category: 'surgery' },
    { title: 'Transvaginal and Transurethral Radiofrequency Tissue Remodeling for Urinary Stress Incontinence', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-136/IV-136-007.html', category: 'surgery' },
    { title: 'Removal of Benign Skin Lesions', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-138/IV-138-006.html', category: 'surgery' },
    { title: 'Baroreflex Stimulation Devices', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-139/IV-139-007.html', category: 'surgery' },
    { title: 'Steroid-Eluting Devices for Maintaining Sinus Ostial Patency', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-140/IV-140-007.html', category: 'surgery' },
    { title: 'Endovascular Therapies for Extracranial Vertebral Artery Disease', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-141/IV-141-006.html', category: 'surgery' },
    { title: 'Saturation Biopsy of the Prostate', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-142/IV-142-006.html', category: 'surgery' },
    { title: 'Closure Devices for Atrial Septal Defects and Patent Foramen Ovale', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-143/IV-143-006.html', category: 'surgery' },
    { title: 'Viscocanalostomy and Canaloplasty for the Treatment of Glaucoma', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-144/IV-144-006.html', category: 'surgery' },
    { title: 'Aqueous Shunts and Stents for Glaucoma', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-146/IV-146-006.html', category: 'surgery' },
    { title: 'Nerve Graft with Prostatectomy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-147/IV-147-006.html', category: 'surgery' },
    { title: 'Prostatic Urethral Lift', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-148/IV-148-006.html', category: 'surgery' },
    { title: 'Endothelial Keratoplasty', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-150/IV-150-006.html', category: 'surgery' },
    { title: 'Composite Tissue Allotransplantation of the Hand', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-151/IV-151-006.html', category: 'surgery' },
    { title: 'Transcatheter Mitral Valve Repair', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-152/IV-152-006.html', category: 'surgery' },
    { title: 'Synthetic Cartilage Implants for Metatarsophalangeal Joint Disorders', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-153/IV-153-006.html', category: 'surgery' },
    { title: 'Artificial Retinal Devices', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-154/IV-154-006.html', category: 'surgery' },
    { title: 'Transcatheter Pulmonary Valve Implantation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-155/IV-155-006.html', category: 'surgery' },
    { title: 'Surgical Treatments of Lymphedema', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-158/IV-158-006.html', category: 'surgery' },
    { title: 'Peroral Endoscopic Myotomy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-159/IV-159-005.html', category: 'surgery' },
    { title: 'Orthognathic Surgery', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-16/IV-16-012.html', category: 'surgery' },
    { title: 'Percutaneous Ultrasonic Ablation of Soft Tissue', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-160/IV-160-006.html', category: 'surgery' },
    { title: 'Responsive Neurostimulation for the Treatment of Refractory Focal (Partial) Epilepsy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-161/IV-161-007.html', category: 'surgery' },
    { title: 'Balloon Dilation of the Eustachian Tube', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-162/IV-162-005.html', category: 'surgery' },
    { title: 'Water Vapor Energy Ablation and Waterjet Tissue Ablation for Benign Prostatic Hyperplasia', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-163/IV-163-005.html', category: 'surgery' },
    { title: 'Perirectal Spacer for Use During Radiotherapy for Prostate Cancer', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-164/IV-164-005.html', category: 'surgery' },
    { title: 'Absorbable Nasal Implant for Treatment of Nasal Valve Collapse', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-165/IV-165-005.html', category: 'surgery' },
    { title: 'Occipital Nerve Decompression for Treatment of Chronic Headache', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-167/iv-167-004.html', category: 'surgery' },
    { title: 'Hysterectomy Surgery for Non-Malignant Conditions', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-168/iv-168-004.html', category: 'surgery' },
    { title: 'Percutaneous Left Atrial Appendage Occluder Devices', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-169/iv-169-004.html', category: 'surgery' },
    { title: 'Bunionectomy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-171/iv-171-003.html', category: 'surgery' },
    { title: 'Nasal Tissue Reduction', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-172/iv-172-002.html', category: 'surgery' },
    { title: 'Surgery for Groin Pain', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-173/iv-173-002.html', category: 'surgery' },
    { title: 'Functional Endoscopic Sinus Surgery (FESS)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-174/iv-174-001.html', category: 'surgery' },
    { title: 'Carpal Tunnel Decompression', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-176/iv-176-001.html', category: 'surgery' },
    { title: 'Prostatic Artery Embolization for Benign Prostatic Hyperplasia (BPH)', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-177/iv-177-001.html', category: 'surgery' },
    { title: 'Panniculectomy/Excision of Redundant Skin or Tissue', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-24/IV-24-016.html', category: 'surgery' },
    { title: 'Risk-Reducing Mastectomy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-27/IV-27-007.html', category: 'surgery' },
    { title: 'Gastric Electrical Stimulation', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-28/IV-28-006.html', category: 'surgery' },
    { title: 'Reduction Mammoplasty', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-32/IV-32-012.html', category: 'surgery' },
    { title: 'Mastopexy', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-33/IV-33-012.html', category: 'surgery' },
    { title: 'Implantable Middle Ear Hearing Aids (Semi-Implantable and Fully Implantable) for Moderate to Severe Sensorineural Hearing Loss', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-37/IV-37-010.html', category: 'surgery' },
    { title: 'Angioplasty and/or Stenting for Intracranial Aneurysms and Atherosclerosis', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-48/iv-48-003.html', category: 'surgery' },
    { title: 'Interspinous Process Spacers', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-51/IV-51-011.html', category: 'surgery' },
    { title: 'Dynamic Spine Stabilization', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-52/IV-52-010.html', category: 'surgery' },
    { title: 'Gynecomastia Surgery', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-71/IV-71-007.html', category: 'surgery' },
    { title: 'Implanted Hypoglossal Nerve Stimulation for the Treatment of Obstructive Sleep Apnea', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/iv-80/iv-80-004.html', category: 'surgery' },
    { title: 'Liposuction', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-82/IV-82-011.html', category: 'surgery' },
    { title: 'Sacral Nerve Neuromodulation/Stimulation for Selected Conditions', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-83/IV-83-007.html', category: 'surgery' },
    { title: 'Ventricular Assist Devices and Total Artificial Hearts', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-86/IV-86-010.html', category: 'surgery' },
    { title: 'Spinal Fusion: Lumbar', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-87/IV-87-012.html', category: 'surgery' },
    { title: 'Percutaneous and Endoscopic Techniques for Disc Decompression', path: 'downloaded_html_files/content/medpolicy/en/minnesota/core/all/policies/Surgery/IV-96/IV-96-010.html', category: 'surgery' },
]; }
